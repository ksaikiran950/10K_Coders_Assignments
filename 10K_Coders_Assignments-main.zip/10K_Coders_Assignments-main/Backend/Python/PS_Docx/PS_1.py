"""1. Area of Square
Question: Calculate the area of a square. - Formula: Area = side × side - Input: - Side = 5 - Output: - Area of square is: 25
"""
a=float(input("Enter a side of Square :"))
def areaofsquare(a):
    return a*a


print(f'Area of Square: {areaofsquare(a)}')

