# n= int(input("enter a number : "))
# def E_or_O(n):
#     if n%2==0:
#         print(n,"is Even")
#     else:
#         print(n,"is Odd")
# E_or_O(n)
    

# n=25

# def satisfy(n):
#     if n%5==0 and n %10 != 0:
#         print("Satisfy")
#     else:
#         print("Not Satisfy")
# satisfy(n)


# n=int(input("enter:"))
# def divisible(n):
#     if n%2==0 and n%3==0 and n%6==0:
#         print("Satisfy ")
#     else:
#         print("Not Satisfy")
# divisible(n)

# def P_or_F(M,P,C):
#     if M>=35 and P>=35 and C>=35:
#         print("Pass")
#     else:
#         print("Fail")
# P_or_F(40,36,30)
# P_or_F(40,36,35)

# def P_or_F(M,P,C):
#     if M>=35 or P>=35 or C>=35:
#         print("Pass")
#     else:
#         print("Fail")
# P_or_F(30,33,30)
# P_or_F(40,36,35)

# def P_or_F(M,P,C):
#     if M>P and M >C:
#         print(M,"P is Greater")
#     elif P>M and P>C:
#         print(P,"is greater")
#     else:
#         print(C,"is greater")
# P_or_F(40,36,30)
# P_or_F(10,37,35)
# P_or_F(10,31,35)


# def perfect_square(n):
#     if n < 0:
#         print("Negative numbers cannot be perfect squares.")
#         return
#     root = int(n**0.5)
#     if root * root == n:
#         print(f"{n} is a perfect square.")
#     else:
#         print(f"{n} is not a perfect square.")
# perfect_square(16)
# perfect_square(20)

# n=3

# cars=n/5
# print(cars)
# if cars==int(cars):
#     print(int(cars),"cars are needed")
# else:
#     print(int(cars)+1,"cars are needed")
