"""Task:
find largest and second largest from given list of numbers.
ip=['sravani','sravan','kumar','kumari','lalitha','lalith','arjun','lakshmi','nandini']
op=[(('sravani','female'),('sravan','male'),('kumar','male'))
"""


# l1=[5,8,7,6,41,19,15]
# fl=l1[0]
# sl=l1[0]
# for e in l1:
#     if e>fl:
#         sl=fl
#         fl=e
#     elif e>sl and e != fl:
#         sl=e
# print("first",fl)
# print("second",sl)